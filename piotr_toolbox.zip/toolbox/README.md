http://vision.ucsd.edu/~pdollar/toolbox/doc/
